package tTour.dao;

public @interface Overload {

}
